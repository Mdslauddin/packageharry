from setuptools import setup

setup(name='package name',
version='0.1.1',
description="This code with harry",
long_description='This is very very long description',
author='Harry',
packages=['packageharry'],
instaall_require=[])
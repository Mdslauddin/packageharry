def func(number):
   
    print("This is function ")
  
    return number


def good():
    return print("Hello")

